export const API_URL = "https://beta.pokeapi.co/graphql/v1beta";

export const SPRITE_BASE_URL =
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/";
