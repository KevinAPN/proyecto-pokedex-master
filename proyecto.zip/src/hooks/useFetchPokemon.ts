import { usePokemon } from "../context/PokemonContext";

export const useFetchPokemon = () => {
    return usePokemon();
};


